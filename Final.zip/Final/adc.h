/*
 * adc.h
 *
 *  Created on: Oct 8, 2020
 *      Author: cml
 */

#ifndef ADC_H_
#define ADC_H_


void adc_init(void);
int adc_read(void);





#endif /* ADC_H_ */
