/*
 * scan.h
 *
 *  Created on: Oct 29, 2020
 *      Author: cluedtke
 */

#ifndef SCAN_H_
#define SCAN_H_

void scan_read(int angle);

void sendString(char str[]);



#endif /* SCAN_H_ */
